//Source A
import React, { Component } from "react";
import Homepage from "./HomePage";

class App extends Component {
  render() {
    return (
      <div id="Home page" className="App">
        <Homepage />
      </div>
    );
  }
}

export default App;
